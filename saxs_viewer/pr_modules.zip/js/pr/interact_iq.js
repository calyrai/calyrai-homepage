// I(q) interaction logic placeholder
