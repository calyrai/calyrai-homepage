export function parsePDBCa(text){
  const out=[];
  for(const l of text.split(/\r?\n/)){
    if(!l.startsWith("ATOM")) continue;
    if(l.slice(12,16).trim()!=="CA") continue;
    out.push({x:+l.slice(30,38),y:+l.slice(38,46),z:+l.slice(46,54)});
  }
  return out;
}