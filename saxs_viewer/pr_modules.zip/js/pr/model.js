export function rPeakOf(nd) {
  return nd.r0 + nd.dir * (nd.D / nd.alpha);
}
export function phiNormAt(r, r0, D, alpha, dir) {
  const t = dir > 0 ? (r - r0) : (r0 - r);
  if (t <= 0) return 0;
  const phi = Math.pow(t, D) * Math.exp(-alpha * t);
  const tp = D / alpha;
  const p0 = Math.pow(tp, D) * Math.exp(-alpha * tp);
  return phi / (p0 || 1);
}