import { drawAxes } from "./axes.js";
import { state } from "./state.js";
export function drawIQ(canvas) {
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0,0,canvas.width,canvas.height);
  drawAxes(ctx,canvas.width,canvas.height,-2,0,-6,6,
    state.iqPlotMode==="log"?"log q":"q",
    state.iqPlotMode==="log"?"log I(q)":"I(q)");
}