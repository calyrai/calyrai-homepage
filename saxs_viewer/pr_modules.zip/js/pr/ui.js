import { state } from "./state.js";
export function initUI() {
  const D=document.getElementById("DSlider");
  const A=document.getElementById("alphaSlider");
  const u=document.getElementById("unitSelect");
  const iq=document.getElementById("iqScaleSelect");
  D?.addEventListener("input",()=>{for(const i of state.selectedNodes) state.nodes[i].D=+D.value;});
  A?.addEventListener("input",()=>{for(const i of state.selectedNodes) state.nodes[i].alpha=+A.value;});
  u?.addEventListener("change",()=>state.unitMode=u.value);
  iq?.addEventListener("change",()=>state.iqPlotMode=iq.value);
}