export function drawAxes(ctx, W, H, xMin, xMax, yMin, yMax, xLabel, yLabel) {
  const L=60,R=W-30,T=30,B=H-35;
  const xPix=x=>L+(x-xMin)/(xMax-xMin||1e-6)*(R-L);
  const yPix=y=>B-(y-yMin)/(yMax-yMin||1e-6)*(B-T);
  ctx.strokeStyle="#666";
  ctx.beginPath(); ctx.moveTo(L,T); ctx.lineTo(L,B); ctx.moveTo(L,B); ctx.lineTo(R,B); ctx.stroke();
  ctx.fillStyle="#fff"; ctx.font="11px system-ui";
  ctx.fillText(xLabel,(L+R)/2-20,H-5);
  ctx.save(); ctx.translate(15,(T+B)/2); ctx.rotate(-Math.PI/2); ctx.fillText(yLabel,0,0); ctx.restore();
  return {xPix,yPix,left:L,right:R,top:T,bottom:B};
}