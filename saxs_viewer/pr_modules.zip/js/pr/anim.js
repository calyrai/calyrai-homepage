import { state } from "./state.js";
import { drawPR } from "./plot_pr.js";
import { drawIQ } from "./plot_iq.js";
export function startAnimation(pCanvas, iqCanvas){
  function tick(){
    state.pulsePhase+=0.1;
    drawPR(pCanvas); drawIQ(iqCanvas);
    requestAnimationFrame(tick);
  }
  tick();
}