import { CONFIG } from "./config.js";
export function makeRGrid() {
  const dr = CONFIG.rMax / (CONFIG.Nr - 1);
  return { rGrid: Array.from({ length: CONFIG.Nr }, (_, i) => i * dr), dr };
}
export function makeQGrid() {
  const a = Math.log10(CONFIG.qMin), b = Math.log10(CONFIG.qMax);
  return Array.from({ length: CONFIG.Nq + 1 },
    (_, i) => Math.pow(10, a + (b - a) * i / CONFIG.Nq));
}