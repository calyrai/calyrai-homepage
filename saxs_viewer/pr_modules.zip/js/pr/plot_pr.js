import { drawAxes } from "./axes.js";
import { state } from "./state.js";
export function drawPR(canvas) {
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0,0,canvas.width,canvas.height);
  drawAxes(ctx,canvas.width,canvas.height,0,80,-1,1,
    state.unitMode==="nm"?"r (nm)":"r (Å)","P(r)");
}