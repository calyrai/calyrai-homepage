import { initUI } from "./ui.js";
import { startAnimation } from "./anim.js";
export function initPRIQViewer(){
  initUI();
  startAnimation(
    document.getElementById("pCanvas"),
    document.getElementById("iqCanvas")
  );
}