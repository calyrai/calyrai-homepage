export const state = {
  nodes: [],
  selectedNodes: new Set(),
  activeNode: null,
  P: [],
  Iq: [],
  expPrData: null,
  expIqData: null,
  expIqLog: null,
  expIqOffsetLog: 0.0,
  unitMode: "nm",
  iqPlotMode: "log",
  IqScaleLog: 0.0,
  pulsePhase: 0.0
};